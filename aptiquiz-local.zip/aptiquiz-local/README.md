# AptiQuiz

Run the AptiQuiz frontend locally with Node.js and npm.

## Requirements

- Node.js 20.19+ or 22.12+
- npm

## Install and run

1. Extract `aptiquiz-local.zip`.
2. Open a terminal in the extracted `aptiquiz-local` folder.
3. Install dependencies:

   ```bash
   npm install
   ```

4. Start the development server:

   ```bash
   npm run dev
   ```

5. Open the local URL printed in the terminal (usually `http://localhost:5173`).

To create a production build, run `npm run build`. To preview that build locally, run `npm run preview`.

## Demo data

This is a frontend demo. Player settings, question sets, and questions are saved in the browser's local storage on that device. There is no connected account system or multiplayer backend.
