/**
 * Boundary for the browser-only demo. Replace these methods with API calls and
 * a WebSocket subscription when a game service exists. The local clock and
 * mock scores are presentation-only; a connected server must referee answers,
 * deadlines, accepted submissions, and authoritative rankings.
 */
export type JoinRoomInput = { name: string; college: string; code: string };
export const demoService = {
  createRoomCode(): string {
    return Math.random().toString(36).slice(2, 7).toUpperCase().padEnd(5, 'Q');
  },
  joinRoom(input: JoinRoomInput) {
    // Future: POST /rooms/:code/join, then subscribe to the room's WebSocket.
    return { ...input, mode: 'local-demo' as const };
  },
  submitAnswer(optionIndex: number) {
    // Future: send only the chosen option. Never ship the correct answer before reveal.
    return { acceptedLocally: true, optionIndex, mode: 'local-demo' as const };
  },
};
