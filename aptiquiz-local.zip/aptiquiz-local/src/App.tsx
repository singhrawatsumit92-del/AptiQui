import { useEffect, useState, type CSSProperties, type FormEvent, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { Route, Switch, useLocation, Router as WouterRouter, Link } from 'wouter';
import { demoService } from '@/lib/demo-service';
import {
  Activity, ArrowDown, ArrowRight, ArrowUp, Award, BarChart3, Bell, BookOpen, Brain,
  Check, CheckCircle2, CircleHelp, Clock3, Copy, Crown, Flame, Gamepad2, GraduationCap,
  Headphones, Home, Layers3, Lightbulb, ListChecks, LockKeyhole, Menu, Moon,
  MoreHorizontal, Plus, Radio, Share2, ShieldCheck, Star, Target, Trophy, Users,
  Volume2, VolumeX, Zap,
} from 'lucide-react';

const queryClient = new QueryClient();
type Question = { id?: string; setId?: string; text: string; options: string[]; correct: number; topic: string; difficulty: string; explanation: string };
type SetItem = { id: string; name: string; topic: string; difficulty: string; questions: number; status: string };
const DEMO_QUESTIONS: Question[] = [
  { text: 'A train 180 metres long crosses a pole in 12 seconds. What is its speed?', options: ['45 km/h', '54 km/h', '60 km/h', '72 km/h'], correct: 1, topic: 'Quantitative', difficulty: 'Medium', explanation: 'Speed = distance ÷ time = 15 m/s, which converts to 54 km/h.' },
  { text: 'If CAT is coded as DBU, how is DOG coded?', options: ['EPH', 'EOG', 'DPH', 'FPH'], correct: 0, topic: 'Logical reasoning', difficulty: 'Easy', explanation: 'Each letter is shifted forward by one place in the alphabet.' },
  { text: 'The average of five numbers is 24. If one number is removed, the average becomes 21. What was removed?', options: ['32', '33', '36', '39'], correct: 2, topic: 'Quantitative', difficulty: 'Medium', explanation: 'The total drops from 120 to 84, so the removed number was 36.' },
];
const DEFAULT_SETS: SetItem[] = [
  { id: 'set-1', name: 'Placement Quantitative Basics', topic: 'Quantitative aptitude', difficulty: 'Medium', questions: 25, status: 'Published' },
  { id: 'set-2', name: 'Logic Under Pressure', topic: 'Logical reasoning', difficulty: 'Hard', questions: 18, status: 'Published' },
  { id: 'set-3', name: 'Verbal Sprint', topic: 'Verbal ability', difficulty: 'Easy', questions: 20, status: 'Draft' },
];
const PLAYER_ROWS = [
  { name: 'Rahul Sharma', college: 'Northbridge Institute', correct: '9 / 10', accuracy: '92%', score: '8,450', move: 2 },
  { name: 'Priya Nair', college: 'Northbridge Institute', correct: '9 / 10', accuracy: '89%', score: '8,100', move: -1 },
  { name: 'Aman Verma', college: 'Eastlake University', correct: '8 / 10', accuracy: '86%', score: '7,920', move: 1 },
  { name: 'You · Aarav', college: 'Northbridge Institute', correct: '8 / 10', accuracy: '82%', score: '7,680', move: 3 },
  { name: 'Neha Kapoor', college: 'Meridian College', correct: '7 / 10', accuracy: '78%', score: '7,210', move: -2 },
];
const initial = <T,>(key: string, fallback: T): T => {
  try { const saved = localStorage.getItem(`aptiquiz:${key}`); return saved ? JSON.parse(saved) as T : fallback; } catch { return fallback; }
};
function persist(key: string, value: unknown) { try { localStorage.setItem(`aptiquiz:${key}`, JSON.stringify(value)); } catch { /* local demo persistence is optional */ } }

const playerNav = [
  { label: 'Overview', href: '/', icon: Home },
  { label: 'Join a room', href: '/join', icon: Gamepad2 },
  { label: 'Daily challenge', href: '/daily', icon: Zap },
  { label: 'Team battle', href: '/team', icon: Users },
  { label: 'Leaderboard', href: '/leaderboard', icon: Trophy },
  { label: 'College league', href: '/league', icon: GraduationCap },
  { label: 'My analytics', href: '/analytics', icon: BarChart3 },
];
const hostNav = [
  { label: 'Host dashboard', href: '/host', icon: Activity },
  { label: 'Question sets', href: '/host/sets', icon: Layers3 },
  { label: 'Author questions', href: '/host/questions', icon: Plus },
  { label: 'Host analytics', href: '/host/analytics', icon: BarChart3 },
];
function IconButton({ label, children, onClick, testId }: { label: string; children: ReactNode; onClick: () => void; testId: string }) {
  return <button type="button" aria-label={label} title={label} className="icon-btn" data-testid={testId} onClick={onClick}>{children}</button>;
}
function Button({ children, onClick, href, variant = 'primary', testId, className = '', type = 'button', disabled = false }: {
  children: ReactNode; onClick?: () => void; href?: string; variant?: string; testId: string; className?: string; type?: 'button' | 'submit'; disabled?: boolean;
}) {
  const classes = `btn btn-${variant} ${className}`;
  if (href) return <Link href={href} className={classes} data-testid={testId}>{children}</Link>;
  return <button type={type} className={classes} data-testid={testId} disabled={disabled} onClick={onClick}>{children}</button>;
}
function PageHeading({ eyebrow, title, subtitle, action }: { eyebrow: string; title: string; subtitle: string; action?: ReactNode }) {
  return <div className="page-head"><div><div className="eyebrow">{eyebrow}</div><h1>{title}</h1><p className="page-sub">{subtitle}</p></div>{action}</div>;
}
function Card({ title, subtitle, children, className = '', testId, style }: { title?: string; subtitle?: string; children: ReactNode; className?: string; testId?: string; style?: CSSProperties }) {
  return <section className={`card ${className}`} data-testid={testId} style={style}>{title && <div style={{ marginBottom: 18 }}><h2 className="card-title">{title}</h2>{subtitle && <p className="card-sub">{subtitle}</p>}</div>}{children}</section>;
}
function Stat({ label, value, icon: Icon, delta }: { label: string; value: string; icon: typeof Users; delta?: string }) {
  return <div className="card stat-card" data-testid={`stat-${label.toLowerCase().replaceAll(' ', '-')}`}><Icon className="stat-icon" size={19} /><div className="stat-value">{value}</div><div className="stat-label">{label}{delta && <span style={{ color: '#36835d', marginLeft: 8 }}>{delta}</span>}</div></div>;
}

function Router() {
  const [location, setLocation] = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);
  const [dark, setDark] = useState(false);
  const [sound, setSound] = useState(() => initial('sound', false));
  const [toast, setToast] = useState('');
  const [sets, setSets] = useState<SetItem[]>(() => initial('sets', DEFAULT_SETS));
  const [roomCode, setRoomCode] = useState(() => initial('roomCode', 'A7K92'));
  const [joined, setJoined] = useState(() => initial('joined', { name: 'Aarav Mehta', college: 'Northbridge Institute' }));
  const [period, setPeriod] = useState('Week');
  const [questionIndex, setQuestionIndex] = useState(0);
  const [answer, setAnswer] = useState<number | null>(null);
  const [revealed, setRevealed] = useState(false);
  const [seconds, setSeconds] = useState(15);
  const [notifications, setNotifications] = useState(true);
  const [questions, setQuestions] = useState<Question[]>(() => initial('questions', []));
  const [selectedQuestionSetId, setSelectedQuestionSetId] = useState(() => initial('selectedQuestionSetId', 'set-3'));
  const [activeGameSetId, setActiveGameSetId] = useState(() => initial('activeGameSetId', ''));
  const notify = (message: string) => { setToast(message); window.setTimeout(() => setToast(''), 2600); };
  useEffect(() => { persist('sound', sound); }, [sound]);
  useEffect(() => { persist('sets', sets); }, [sets]);
  useEffect(() => { persist('roomCode', roomCode); }, [roomCode]);
  useEffect(() => { persist('joined', joined); }, [joined]);
  useEffect(() => { persist('questions', questions); }, [questions]);
  useEffect(() => { persist('selectedQuestionSetId', selectedQuestionSetId); }, [selectedQuestionSetId]);
  useEffect(() => { persist('activeGameSetId', activeGameSetId); }, [activeGameSetId]);
  useEffect(() => { setMenuOpen(false); }, [location]);
  useEffect(() => {
    if (location !== '/game' || revealed) return;
    const timer = window.setInterval(() => setSeconds((s) => Math.max(0, s - 1)), 1000);
    return () => window.clearInterval(timer);
  }, [location, revealed, questionIndex]);
  useEffect(() => { if (location === '/game' && seconds === 0) setRevealed(true); }, [seconds, location]);
  const authoredGameQuestions = questions.filter((question) => question.setId === activeGameSetId);
  const gameQuestions = authoredGameQuestions.length ? authoredGameQuestions : DEMO_QUESTIONS;
  const gameQuestion = gameQuestions[questionIndex % gameQuestions.length];
  const gameStep = (next: number) => {
    if (next >= gameQuestions.length) { setQuestionIndex(0); setAnswer(null); setRevealed(false); setSeconds(15); setLocation('/results'); }
    else { setQuestionIndex(next); setAnswer(null); setRevealed(false); setSeconds(15); }
  };
  const share = async (text: string) => {
    try { await navigator.clipboard.writeText(text); notify('Copied to clipboard'); }
    catch { notify(text); }
  };
  const createRoom = () => {
    const code = demoService.createRoomCode();
    setRoomCode(code); notify(`Practice room ${code} is ready`);
  };
  const deleteSet = (id: string) => { setSets((all) => all.filter((set) => set.id !== id)); notify('Question set removed'); };
  const createSet = () => {
    const set = { id: `set-${Date.now()}`, name: 'Untitled placement set', topic: 'General aptitude', difficulty: 'Medium', questions: 0, status: 'Draft' };
    setSets((all) => [...all, set]); setSelectedQuestionSetId(set.id); notify('Draft question set created'); setLocation('/host/questions');
  };
  const editSet = (set: SetItem) => {
    const name = window.prompt('Rename question set', set.name);
    if (name?.trim()) { setSets((all) => all.map((item) => item.id === set.id ? { ...item, name: name.trim() } : item)); notify('Question set updated'); }
  };
  const duplicateSet = (set: SetItem) => { setSets((all) => [...all, { ...set, id: `set-${Date.now()}`, name: `${set.name} copy`, status: 'Draft' }]); notify('Set duplicated'); };
  const exportRows = () => {
    const csv = ['Rank,Player,College,Correct,Accuracy,Score', ...PLAYER_ROWS.map((r, i) => `${i + 1},${r.name},${r.college},${r.correct},${r.accuracy},${r.score}`)].join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = 'aptiquiz-results-demo.csv'; a.click(); URL.revokeObjectURL(url); notify('Demo results exported');
  };
  const navLink = (item: typeof playerNav[number]) => <Link key={item.href} href={item.href} className={`nav-link ${location === item.href ? 'active' : ''}`} data-testid={`link-${item.href.replaceAll('/', '') || 'home'}`}><item.icon size={17} /><span>{item.label}</span></Link>;
  const content = <Switch>
    <Route path="/" component={() => <HomePage notify={notify} />} />
    <Route path="/join" component={() => <JoinPage onJoin={(name, college, code) => { demoService.joinRoom({ name, college, code }); setJoined({ name, college }); setRoomCode(code); persist('joined', { name, college }); notify('You are in the room'); }} />} />
    <Route path="/host" component={() => <HostPage createRoom={createRoom} sets={sets} notify={notify} />} />
    <Route path="/host/sets" component={() => <SetsPage sets={sets} onDelete={deleteSet} onDuplicate={duplicateSet} onCreate={createSet} onEdit={editSet} onStartGame={(set) => { setActiveGameSetId(set.id); setSelectedQuestionSetId(set.id); setQuestionIndex(0); setAnswer(null); setRevealed(false); setSeconds(15); setLocation('/lobby'); notify(`${set.name} is ready for a practice round`); }} notify={notify} />} />
    <Route path="/host/questions" component={() => <AuthorPage sets={sets} questions={questions} selectedSetId={selectedQuestionSetId} onSelectSet={setSelectedQuestionSetId} onCreateSet={createSet} onSave={(q, setId) => { const question = { ...q, id: `question-${Date.now()}`, setId }; setQuestions((all) => [...all, question]); setSets((all) => all.map((item) => item.id === setId ? { ...item, questions: item.questions + 1 } : item)); }} notify={notify} />} />
    <Route path="/lobby" component={() => <LobbyPage code={roomCode} player={joined.name} notify={notify} />} />
    <Route path="/game" component={() => <GamePage question={gameQuestion} number={questionIndex + 1} total={gameQuestions.length} answer={answer} setAnswer={(a) => { if (a !== null && answer === null) demoService.submitAnswer(a); setAnswer(a); }} revealed={revealed} setRevealed={setRevealed} seconds={seconds} onNext={() => gameStep(questionIndex + 1)} />} />
    <Route path="/leaderboard" component={() => <LeaderboardPage notify={notify} />} />
    <Route path="/results" component={() => <ResultsPage notify={notify} exportRows={exportRows} />} />
    <Route path="/analytics" component={() => <PlayerAnalytics />} />
    <Route path="/league" component={() => <LeaguePage period={period} setPeriod={setPeriod} />} />
    <Route path="/daily" component={() => <DailyPage notify={notify} />} />
    <Route path="/team" component={() => <TeamPage notify={notify} />} />
    <Route path="/host/analytics" component={() => <HostAnalytics exportRows={exportRows} />} />
    <Route component={NotFound} />
  </Switch>;
  const game = location === '/game';
  return <div className={`app-shell ${game || dark ? 'game-mode' : ''}`}>
    <aside className={`side-nav ${menuOpen ? 'open' : ''}`} aria-label="Main navigation">
      <Link href="/" className="brand" data-testid="link-aptiquiz-home"><span className="brand-mark"><Zap size={19} fill="currentColor" /></span>AptiQuiz</Link>
      <div className="nav-caption">Player space</div><nav className="nav-list">{playerNav.map(navLink)}</nav>
      <div className="nav-caption" style={{ marginTop: 14 }}>Host studio</div><nav className="nav-list">{hostNav.map(navLink)}</nav>
      <div className="nav-bottom">
        <Link href="/join" className="nav-link" data-testid="link-join-cta"><Headphones size={17} /><span>Need a room code?</span></Link>
        <div style={{ padding: '12px 10px 0', color: '#8292ac', fontSize: 10, lineHeight: 1.6 }}>A practice arena for the next big offer.</div>
      </div>
    </aside>
    <div className="content-area">
      <header className="topbar">
        <div className="topbar-left"><IconButton label="Open navigation" testId="button-open-navigation" onClick={() => setMenuOpen(!menuOpen)}><Menu size={17} /></IconButton><span>AptiQuiz /</span><strong>{(location.split('/').filter(Boolean).pop() || 'overview').replaceAll('-', ' ')}</strong></div>
        <div className="top-actions">
          <button className="icon-btn" aria-label={sound ? 'Mute sound' : 'Enable sound'} title="Sound preference" data-testid="button-sound-toggle" onClick={() => { setSound(!sound); notify(sound ? 'Sound off' : 'Sound on'); }}>{sound ? <Volume2 size={16} /> : <VolumeX size={16} />}</button>
          <button className="icon-btn hide-mobile" aria-label="Toggle dark theme" title="Toggle theme" data-testid="button-theme-toggle" onClick={() => setDark(!dark)}>{dark ? <Moon size={15} /> : <Lightbulb size={15} />}</button>
          <button className="icon-btn hide-mobile" aria-label="Toggle notifications" title="Toggle notifications" data-testid="button-notifications" onClick={() => { setNotifications(!notifications); notify(notifications ? 'Notifications paused' : 'Notifications enabled'); }}><Bell size={16} /><span style={{ position: 'absolute', margin: '-18px 0 0 17px', width: 6, height: 6, borderRadius: '50%', background: notifications ? '#e4ae35' : '#b6c2d3' }} /></button>
          <div className="avatar" data-testid="text-user-avatar">{joined.name.split(' ').map((w) => w[0]).slice(0, 2).join('')}</div>
        </div>
      </header>
      {content}
    </div>
    {toast && <div role="status" className="toast" data-testid="status-toast">{toast}</div>}
  </div>;
}

function HomePage({ notify }: { notify: (text: string) => void }) {
  const features = [
    [Radio, 'Room-based live play', 'Get your group in one room and turn prep into a fast, friendly face-off.'],
    [Trophy, 'A leaderboard with stakes', 'Every round moves the table. Accuracy comes first; pace adds the edge.'],
    [Target, 'Speed meets precision', 'Build the calm, quick decision-making placement tests reward.'],
    [GraduationCap, 'College leagues', 'See how your campus stacks up across daily, weekly, and seasonal play.'],
    [BarChart3, 'Topic-level insight', 'Spot your strongest topics and make your next practice count.'],
    [ShieldCheck, 'Fair by design', 'Demo rounds are for practice. Official timing and scoring belong on the game server.'],
  ] as const;
  return <>
    <section className="hero">
      <div className="reveal"><div className="eyebrow" style={{ color: '#f0c24e' }}>Placement prep, with a pulse</div><h1>Turn aptitude practice into a <em>competition.</em></h1><p className="hero-tagline">Think Fast. Answer Smart. Rise to the Top.</p><p className="hero-copy">Aptitude practice hits different when your friends are in the room. Take on quick-fire questions, sharpen your instincts, and climb your college ranks.</p><div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}><Button href="/join" testId="button-hero-join">Join a room <ArrowRight size={15} /></Button><Button href="/host" variant="secondary" testId="button-hero-host">Host a session</Button></div><div style={{ marginTop: 22, color: '#9cacbf', fontSize: 10, display: 'flex', alignItems: 'center', gap: 8 }}><Users size={14} /> Built for study groups, societies, and placement cells</div></div>
      <div className="hero-visual" aria-label="AptiQuiz question preview"><div className="score-board"><div className="score-top"><span>ROUND 04 <span style={{ color: '#70819d' }}>/ 10</span></span><span><Clock3 size={13} style={{ verticalAlign: 'middle', marginRight: 5 }} />00:12</span></div><div className="score-question">What number comes next?<br /><span style={{ color: '#a7b8d0', fontSize: 13 }}>3, 8, 15, 24, 35, ...</span></div><div className="score-option">A&nbsp;&nbsp; 46</div><div className="score-option chosen">B&nbsp;&nbsp; 48 <Check size={13} style={{ float: 'right' }} /></div><div className="score-option">C&nbsp;&nbsp; 49</div></div><div className="hero-float"><Zap size={14} style={{ verticalAlign: 'middle', marginRight: 5 }} /> STREAK +1</div></div>
    </section>
    <section className="section"><div className="section-heading"><div><div className="eyebrow">Not another worksheet</div><h2>Practice with a little pressure.</h2></div><p className="page-sub">Serious prep. Better company.</p></div><div className="grid grid-3">{features.map(([Icon, title, desc], i) => <div className="card feature-card" key={title} data-testid={`card-feature-${i}`}><div className="feature-icon"><Icon size={18} /></div><h3 className="card-title">{title}</h3><p>{desc}</p></div>)}</div></section>
    <section className="section" style={{ paddingTop: 8 }}><div className="grid grid-2"><Card title="Four moves. One sharper you." subtitle="A practice loop that feels like game day"><div className="steps">{['Pick a question set', 'Join your friends in a room', 'Answer against the clock', 'Take your place on the board'].map((item) => <div className="step" key={item}><span style={{ fontSize: 12, fontWeight: 700, color: '#364761' }}>{item}</span><ArrowRight size={14} color="#8ba0bd" style={{ marginLeft: 'auto' }} /></div>)}</div></Card><div style={{ background: '#e7effb', borderRadius: 16, padding: 25, display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}><div><div className="eyebrow">The campus circuit</div><h2 style={{ font: '700 24px Space Grotesk', color: '#18294a', margin: '0 0 12px' }}>Your next practice partner is already here.</h2><p className="page-sub">Join a room for a quick round, or bring your whole society together. Local demo results make practice fun; connected play comes later.</p></div><div className="grid grid-4" style={{ margin: '23px 0' }}><div><strong style={{ font: '700 22px Space Grotesk', color: '#1d6fd9' }}>10k+</strong><div className="stat-label">students</div></div><div><strong style={{ font: '700 22px Space Grotesk', color: '#1d6fd9' }}>500+</strong><div className="stat-label">practice sets</div></div><div><strong style={{ font: '700 22px Space Grotesk', color: '#1d6fd9' }}>100+</strong><div className="stat-label">colleges</div></div><div><strong style={{ font: '700 22px Space Grotesk', color: '#1d6fd9' }}>50</strong><div className="stat-label">players per room</div></div></div><Button href="/league" variant="outline" testId="button-home-league">Explore college league <ArrowRight size={14} /></Button></div></div></section>
    <section className="section" style={{ paddingTop: 4 }}><div style={{ background: '#152644', borderRadius: 18, padding: '27px 30px', color: 'white', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 20 }}><div><div className="eyebrow" style={{ color: '#f0c24e' }}>Your next rep starts here</div><h2 style={{ font: '700 24px Space Grotesk', margin: 0 }}>Ready to test your aptitude?</h2></div><div style={{ display: 'flex', gap: 10 }}><Button href="/join" variant="gold" testId="button-home-join">Join a game</Button><Button href="/host" variant="secondary" testId="button-home-host">Start hosting</Button></div></div></section>
  </>;
}
function JoinPage({ onJoin }: { onJoin: (name: string, college: string, code: string) => void }) {
  const [, setLocation] = useLocation();
  const [name, setName] = useState(''); const [college, setCollege] = useState(''); const [code, setCode] = useState(''); const [error, setError] = useState('');
  const submit = (e: FormEvent) => { e.preventDefault(); if (!name.trim()) { setError('Add your name to join the room.'); return; } if (!/^[A-Z0-9]{5}$/i.test(code.trim())) { setError('Room code must be exactly 5 letters or numbers.'); return; } setError(''); onJoin(name.trim(), college.trim() || 'Independent player', code.toUpperCase()); setLocation('/lobby'); };
  return <main className="page"><PageHeading eyebrow="Pull up a seat" title="Join a room" subtitle="Grab the five-character code from your host and get ready to play." /><div className="grid grid-2" style={{ alignItems: 'start' }}><Card title="Room details" subtitle="This browser demo stores your profile on this device."><form onSubmit={submit}><div className="field"><label htmlFor="join-name">Player name</label><input className="input" id="join-name" placeholder="e.g. Aarav Mehta" value={name} onChange={(e) => setName(e.target.value)} data-testid="input-player-name" autoComplete="name" /></div><div className="field"><label htmlFor="join-code">Room code</label><input className="input" id="join-code" placeholder="A7K92" value={code} maxLength={5} onChange={(e) => setCode(e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, ''))} data-testid="input-room-code" style={{ textTransform: 'uppercase', letterSpacing: 2, fontFamily: 'DM Mono' }} /></div><div className="field"><label htmlFor="join-college">College name <span style={{ color: '#8a97aa', fontWeight: 500 }}>(optional)</span></label><input className="input" id="join-college" placeholder="e.g. Northbridge Institute" value={college} onChange={(e) => setCollege(e.target.value)} data-testid="input-college-name" /></div>{error && <div role="alert" className="notice" style={{ borderColor: '#f2c9c4', background: '#fff5f3', color: '#a5443c', marginBottom: 14 }} data-testid="status-join-error">{error}</div>}<Button type="submit" testId="button-join-room" className="btn" >Join game <ArrowRight size={15} /></Button></form></Card><Card title="You’re in good company" subtitle="One code, one room, a friendly race to the top."><div style={{ background: '#f2f6fd', borderRadius: 12, padding: 18, marginBottom: 16 }}><div className="eyebrow">Room code looks like</div><div style={{ font: '700 31px DM Mono', letterSpacing: 4, color: '#1b6fe0' }}>A7K92</div><p className="card-sub" style={{ marginTop: 8 }}>Ask your host for the 5-character room code.</p></div><div style={{ display: 'grid', gap: 12 }}>{[['01', 'Bring your best name', 'Your classmates will see it in the lobby.'], ['02', 'Pick your campus', 'Your score helps your college climb.'], ['03', 'Play for practice', 'This demo uses local data, not official rankings.']].map(([n, title, text]) => <div key={n} style={{ display: 'flex', gap: 12 }}><span style={{ font: '11px DM Mono', color: '#347fdc' }}>{n}</span><div><strong style={{ fontSize: 12, color: '#283a57' }}>{title}</strong><div className="card-sub" style={{ marginTop: 3 }}>{text}</div></div></div>)}</div></Card></div></main>;
}
function HostPage({ createRoom, sets, notify }: { createRoom: () => void; sets: SetItem[]; notify: (s: string) => void }) {
  return <main className="page"><PageHeading eyebrow="Host studio" title="Make practice a team sport." subtitle="Set up a room, choose a question set, and put your group into game-day mode." action={<Button onClick={createRoom} testId="button-create-room"><Plus size={15} /> Create new room</Button>} /><div className="grid grid-4"><Stat label="Question sets" value={`${sets.length}`} icon={Layers3} /><Stat label="Active rooms" value="1" icon={Radio} delta="+1 today" /><Stat label="Players this week" value="186" icon={Users} delta="+12.8%" /><Stat label="Sessions hosted" value="24" icon={Gamepad2} /></div><div className="grid grid-2" style={{ marginTop: 18 }}><Card title="Room at a glance" subtitle="Local demo session · data is not live"><div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 15, flexWrap: 'wrap' }}><div><div className="badge badge-green"><span style={{ width: 6, height: 6, background: '#3a9b67', borderRadius: '50%' }} /> Open for players</div><h3 style={{ font: '700 29px DM Mono', letterSpacing: 3, color: '#1c2d4b', margin: '17px 0 3px' }}>A7K92</h3><div className="card-sub">Placement Quantitative Basics · 12 / 50 players</div></div><Button href="/lobby" variant="secondary" testId="button-host-lobby">Open lobby <ArrowRight size={14} /></Button></div><div className="progress" style={{ marginTop: 21 }}><span style={{ width: '24%' }} /></div></Card><Card title="Quick actions" subtitle="Keep your next round moving"><div style={{ display: 'grid', gap: 10 }}><Button href="/host/sets" variant="outline" testId="button-manage-sets"><Layers3 size={15} /> Manage question sets</Button><Button href="/host/questions" variant="outline" testId="button-author-question"><Plus size={15} /> Author a question</Button><Button href="/host/analytics" variant="outline" testId="button-view-host-analytics"><BarChart3 size={15} /> View session analytics</Button></div></Card></div><Card title="Recent activity" subtitle="A local snapshot of your host studio" className="" ><div className="table-wrap"><table className="table"><thead><tr><th>Session</th><th>Question set</th><th>Players</th><th>Status</th><th>Action</th></tr></thead><tbody><tr><td><strong>Placement warm-up</strong><div className="card-sub">Today · 10:42 AM</div></td><td>Quantitative Basics</td><td>12</td><td><span className="badge badge-green">Lobby open</span></td><td><Button href="/lobby" variant="outline" className="btn-small" testId="button-open-active-lobby">Open</Button></td></tr><tr><td><strong>Logic club Friday</strong><div className="card-sub">Yesterday · 4:16 PM</div></td><td>Logic Under Pressure</td><td>28</td><td><span className="badge">Completed</span></td><td><Button href="/host/analytics" variant="outline" className="btn-small" testId="button-review-session">Review</Button></td></tr></tbody></table></div></Card></main>;
}
function SetsPage({ sets, onDelete, onDuplicate, onCreate, onEdit, onStartGame, notify }: { sets: SetItem[]; onDelete: (id: string) => void; onDuplicate: (s: SetItem) => void; onCreate: () => void; onEdit: (s: SetItem) => void; onStartGame: (s: SetItem) => void; notify: (s: string) => void }) {
  const [, setLocation] = useLocation();
  return <main className="page"><PageHeading eyebrow="Host studio / library" title="Question sets" subtitle="Build a set, remix a favorite, or launch your next practice room." action={<Button onClick={onCreate} testId="button-create-set"><Plus size={15} /> Create a set</Button>} />
     {sets.length ? <div className="grid grid-2">{sets.map((set) => <Card key={set.id} testId={`card-set-${set.id}`}><div style={{ display: 'flex', justifyContent: 'space-between', gap: 12 }}><div><span className={`badge ${set.status === 'Published' ? 'badge-green' : 'badge-gold'}`}>{set.status}</span><h2 className="card-title" style={{ marginTop: 13 }}>{set.name}</h2><p className="card-sub">{set.topic}</p></div><button className="icon-btn" aria-label={`More actions for ${set.name}`} data-testid={`button-set-menu-${set.id}`} onClick={() => notify(`${set.questions} questions · ${set.difficulty} difficulty`)}><MoreHorizontal size={17} /></button></div><div style={{ display: 'flex', gap: 8, margin: '20px 0' }}><span className="badge">{set.questions} questions</span><span className="badge">{set.difficulty}</span><span className="badge">Edited today</span></div><div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}><Button onClick={() => notify(`${set.name} · ${set.questions} questions · ${set.difficulty}`)} variant="outline" className="btn-small" testId={`button-view-${set.id}`}>View</Button><Button onClick={() => onEdit(set)} variant="outline" className="btn-small" testId={`button-edit-${set.id}`}>Edit</Button><Button onClick={() => onDuplicate(set)} variant="outline" className="btn-small" testId={`button-duplicate-${set.id}`}><Copy size={13} /> Duplicate</Button><Button onClick={() => { if (window.confirm(`Delete “${set.name}”?`)) onDelete(set.id); }} variant="danger" className="btn-small" testId={`button-delete-${set.id}`}>Delete</Button><Button onClick={() => onStartGame(set)} className="btn-small" testId={`button-start-${set.id}`}><Gamepad2 size={13} /> Start game</Button></div></Card>)}</div> : <Card><div className="empty"><div className="empty-icon"><BookOpen size={20} /></div><h3 className="card-title">Your library is ready for its first set.</h3><p className="card-sub" style={{ margin: '8px 0 17px' }}>Create a question set and give your next practice session a focus.</p><Button onClick={onCreate} testId="button-empty-create-set"><Plus size={14} /> Create question set</Button></div></Card>}</main>;
}
function AuthorPage({ sets, questions, selectedSetId, onSelectSet, onCreateSet, onSave, notify }: {
  sets: SetItem[];
  questions: Question[];
  selectedSetId: string;
  onSelectSet: (id: string) => void;
  onCreateSet: () => void;
  onSave: (q: Question, setId: string) => void;
  notify: (s: string) => void;
}) {
  const [text, setText] = useState('');
  const [topic, setTopic] = useState('Quantitative');
  const [difficulty, setDifficulty] = useState('Medium');
  const [options, setOptions] = useState(['', '', '', '']);
  const [correct, setCorrect] = useState(0);
  const [preview, setPreview] = useState(false);
  const activeSet = sets.find((set) => set.id === selectedSetId) ?? sets[0];
  const savedForSet = questions.filter((question) => question.setId === activeSet?.id);

  const save = (e: FormEvent) => {
    e.preventDefault();
    if (!activeSet) {
      notify('Create a question set before adding questions.');
      return;
    }
    if (!text.trim() || options.some((option) => !option.trim())) {
      notify('Add a question and all four answer choices first.');
      return;
    }
    onSave({
      text: text.trim(),
      options: options.map((option) => option.trim()),
      correct,
      topic,
      difficulty,
      explanation: 'Review the steps and look for the shortest reliable route.',
    }, activeSet.id);
    setText('');
    setOptions(['', '', '', '']);
    setCorrect(0);
    notify(`Question added to ${activeSet.name}`);
  };

  return <main className="page">
    <PageHeading
      eyebrow="Host studio / question lab"
      title="Write the next good question."
      subtitle="Choose a question set, add your question and answer choices, then save it to that set."
      action={<Button onClick={() => setPreview(!preview)} variant="secondary" testId="button-preview-question"><EyeIcon /> {preview ? 'Close preview' : 'Preview question'}</Button>}
    />
    <div className="grid grid-2" style={{ alignItems: 'start' }}>
      <Card title="Question editor" subtitle="Questions are saved in this browser and added to the selected set.">
        {sets.length ? <div className="field">
          <label htmlFor="question-set">Add question to</label>
          <select id="question-set" className="select" value={activeSet?.id ?? ''} onChange={(e) => onSelectSet(e.target.value)} data-testid="select-question-set">
            {sets.map((set) => <option key={set.id} value={set.id}>{set.name} · {set.questions} questions</option>)}
          </select>
        </div> : <div className="notice" role="status" style={{ marginBottom: 16 }}>
          Create a question set before you add questions.
          <Button onClick={onCreateSet} className="btn-small" testId="button-create-set-for-question"><Plus size={13} /> Create question set</Button>
        </div>}
        <form onSubmit={save}>
          <div className="field">
            <label htmlFor="question-prompt">Question prompt</label>
            <textarea id="question-prompt" className="textarea" placeholder="Write a concise aptitude question…" value={text} onChange={(e) => setText(e.target.value)} data-testid="input-question-prompt" />
          </div>
          <div className="grid grid-2">
            <div className="field">
              <label htmlFor="question-topic">Topic</label>
              <select id="question-topic" className="select" value={topic} onChange={(e) => setTopic(e.target.value)} data-testid="select-question-topic">
                {['Quantitative', 'Logical reasoning', 'Verbal ability', 'Data interpretation', 'General aptitude'].map((item) => <option key={item}>{item}</option>)}
              </select>
            </div>
            <div className="field">
              <label htmlFor="question-difficulty">Difficulty</label>
              <select id="question-difficulty" className="select" value={difficulty} onChange={(e) => setDifficulty(e.target.value)} data-testid="select-question-difficulty">
                {['Easy', 'Medium', 'Hard'].map((item) => <option key={item}>{item}</option>)}
              </select>
            </div>
          </div>
          <div style={{ display: 'grid', gap: 9, marginBottom: 16 }}>
            {options.map((option, index) => <div key={index} style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
              <input type="radio" name="correct-answer" aria-label={`Set option ${String.fromCharCode(65 + index)} as correct`} checked={correct === index} onChange={() => setCorrect(index)} data-testid={`radio-correct-option-${index}`} />
              <input className="input" placeholder={`Option ${String.fromCharCode(65 + index)}`} value={option} onChange={(e) => setOptions((old) => old.map((value, optionIndex) => optionIndex === index ? e.target.value : value))} data-testid={`input-option-${index}`} />
            </div>)}
          </div>
          <div style={{ display: 'flex', gap: 9, flexWrap: 'wrap' }}>
            <Button type="submit" disabled={!activeSet} testId="button-save-question"><Check size={15} /> Add question to set</Button>
            <Button onClick={() => { setText(''); setOptions(['', '', '', '']); setCorrect(0); }} variant="outline" testId="button-clear-question">Clear</Button>
            <label className="btn btn-outline btn-small" style={{ cursor: 'pointer' }}><Plus size={13} /> Upload image<input type="file" accept="image/*" hidden data-testid="input-question-image" onChange={(e) => e.target.files?.[0] && notify(`${e.target.files[0].name} selected for local preview`)} /></label>
          </div>
        </form>
      </Card>
      <div style={{ display: 'grid', gap: 16 }}>
        <Card title={preview ? 'Player preview' : 'Questions in this set'} subtitle={preview ? 'Local preview only · not a live game' : `${savedForSet.length} question${savedForSet.length === 1 ? '' : 's'} added to ${activeSet?.name ?? 'this set'} on this device`}>
          {preview ? <div className="reveal">
            <span className="badge badge-blue">{topic} · {difficulty}</span>
            <h3 style={{ font: '700 19px Space Grotesk', color: '#203352', marginTop: 18 }}>{text || 'Your question will appear here.'}</h3>
            {options.map((option, index) => <div key={index} className="question-option" style={{ background: correct === index ? '#e8f5ee' : '#f5f8fc', color: '#273b58', borderColor: correct === index ? '#90c6a5' : '#e1e8f1', marginTop: 9, cursor: 'default' }}>
              <span className="option-letter">{String.fromCharCode(65 + index)}</span>{option || `Option ${String.fromCharCode(65 + index)}`}
            </div>)}
          </div> : savedForSet.length ? <div style={{ display: 'grid', gap: 12 }}>
            {savedForSet.slice().reverse().map((question, index) => <div key={question.id ?? `${question.text}-${index}`} style={{ borderBottom: '1px solid #edf1f6', paddingBottom: 12 }}>
              <span className="badge">{question.topic} · {question.difficulty}</span>
              <p style={{ fontSize: 12, color: '#344762', margin: '8px 0' }}>{question.text}</p>
              <span className="card-sub">Correct answer: {String.fromCharCode(65 + question.correct)} · {question.options[question.correct]}</span>
            </div>)}
          </div> : <div className="empty" style={{ padding: 19 }}>
            <div className="empty-icon"><ListChecks size={19} /></div>
            <p className="card-sub">No questions have been added to this set on this device yet. Use the form to add the first one.</p>
          </div>}
        </Card>
        <div className="notice" style={{ background: '#f0f5ff', borderColor: '#d9e6fb', color: '#4c6384' }}>
          <LockKeyhole size={14} style={{ verticalAlign: 'middle', marginRight: 7 }} />
          Questions are stored in this browser for the demo. A future game server must keep correct answers hidden until each round ends.
        </div>
      </div>
    </div>
  </main>;
}
function EyeIcon() { return <CircleHelp size={15} />; }
function LobbyPage({ code, player, notify }: { code: string; player: string; notify: (s: string) => void }) {
  const players = [player, 'Priya Nair', 'Rahul Sharma', 'Ishita Rao', 'Kabir Shah', 'Maya Das'];
  return <main className="page"><PageHeading eyebrow="Room A7K92 · local practice" title="The room is warming up." subtitle="Waiting for the host to start. Say hi, check your setup, and get focused." action={<span className="badge badge-green"><span style={{ width: 6, height: 6, background: '#3a9b67', borderRadius: '50%' }} /> Connected · demo</span>} /><div className="grid grid-2" style={{ alignItems: 'start' }}><Card title="Room code" subtitle="Share this with your study group"><div style={{ background: '#f1f6fe', borderRadius: 13, padding: 22, textAlign: 'center' }}><div className="eyebrow">Join code</div><div style={{ font: '700 clamp(35px,7vw,55px) DM Mono', color: '#1a67d1', letterSpacing: 8 }} data-testid="text-room-code">{code}</div><Button onClick={() => { navigator.clipboard?.writeText(code).catch(() => undefined); notify('Room code copied'); }} variant="outline" className="btn-small" testId="button-copy-room-code"><Copy size={13} /> Copy code</Button></div><div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 19, fontSize: 12 }}><span style={{ color: '#71809a' }}>Players in room</span><strong data-testid="text-player-capacity">6 / 50</strong></div><div className="progress" style={{ marginTop: 8 }}><span style={{ width: '12%' }} /></div><p className="card-sub" style={{ marginTop: 10 }}>A local preview room. Player count is sample data.</p></Card><Card title="Your squad" subtitle="The people taking on this round"><div style={{ display: 'grid', gap: 6 }}>{players.map((name, i) => <div key={name} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '9px 4px', borderBottom: i < players.length - 1 ? '1px solid #edf1f6' : 'none' }} data-testid={`row-lobby-player-${i}`}><div className="avatar" style={{ background: i === 0 ? '#dceaff' : '#edf1f7', color: '#476486' }}>{name.split(' ').map((s) => s[0]).join('')}</div><div style={{ flex: 1 }}><strong style={{ color: '#243753', fontSize: 12 }}>{name}</strong><div className="card-sub">{i === 0 ? 'You · player' : i === 1 ? 'Host' : 'Player'}</div></div>{i === 1 ? <span className="badge badge-gold">Host</span> : i === 0 ? <span className="badge badge-blue">You</span> : <CheckCircle2 size={15} color="#58a578" />}</div>)}</div></Card></div><div className="card" style={{ marginTop: 17, background: '#162746', color: 'white', display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 18, flexWrap: 'wrap' }}><div><h2 style={{ color: 'white', font: '700 17px Space Grotesk', margin: '0 0 5px' }}>Waiting for the host…</h2><p style={{ color: '#9babC3', fontSize: 11, margin: 0 }}>Take a breath. Fast is good; accurate is better.</p></div><Button href="/game" variant="gold" testId="button-demo-start-game">Start demo round <ArrowRight size={14} /></Button></div></main>;
}
function GamePage({ question, number, total, answer, setAnswer, revealed, setRevealed, seconds, onNext }: { question: Question; number: number; total: number; answer: number | null; setAnswer: (a: number | null) => void; revealed: boolean; setRevealed: (x: boolean) => void; seconds: number; onNext: () => void }) {
  const [, setLocation] = useLocation();
  return <main className="page"><PageHeading eyebrow={`Round ${number} / ${total} · ${question.topic}`} title="Trust your first read." subtitle="One selection per round. The answer reveal below is a demo result, never official scoring." action={<span className="badge badge-green"><Radio size={12} /> Local demo</span>} /><div className="grid grid-2" style={{ gridTemplateColumns: 'minmax(0,1fr) 270px', alignItems: 'start' }}><Card className="" testId="card-game-question"><div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 12, marginBottom: 24 }}><div><span className="badge badge-blue">{question.difficulty}</span><span className="badge" style={{ marginLeft: 7 }}>Question {number} of {total}</span></div><div className={`timer ${seconds < 5 ? 'is-low' : ''}`} aria-label={`${seconds} seconds remaining`} data-testid="text-display-timer">00:{String(seconds).padStart(2, '0')}</div></div><h2 style={{ font: '700 clamp(20px,3vw,27px)/1.35 Space Grotesk', color: '#eff4fc', marginBottom: 24 }} data-testid="text-game-question">{question.text}</h2><div style={{ display: 'grid', gap: 10 }}>{question.options.map((option, i) => <button type="button" key={option} disabled={answer !== null || revealed} className={`question-option ${answer === i ? 'selected' : ''}`} onClick={() => setAnswer(i)} data-testid={`button-answer-${i}`}><span className="option-letter">{String.fromCharCode(65 + i)}</span>{option}{answer === i && <Check size={16} style={{ marginLeft: 'auto', color: '#83b9ff' }} />}</button>)}</div>{answer !== null && !revealed && <div role="status" className="notice" style={{ marginTop: 17, background: '#1b3558', color: '#bbd9ff', borderColor: '#315580' }} data-testid="status-answer-submitted"><CheckCircle2 size={15} style={{ verticalAlign: 'middle', marginRight: 6 }} /> Answer submitted. Waiting for the round reveal…</div>}{revealed && <div className="reveal" style={{ marginTop: 17, padding: 17, borderRadius: 11, background: answer === question.correct ? '#173d35' : '#392b35', border: `1px solid ${answer === question.correct ? '#326c5a' : '#70434c'}` }} data-testid="status-round-result"><div className="eyebrow" style={{ color: answer === question.correct ? '#7bd6a8' : '#f3a398' }}>{answer === question.correct ? 'Correct answer' : 'Round complete'}</div><strong style={{ color: '#fff', fontSize: 15 }}>Answer {String.fromCharCode(65 + question.correct)} · {answer === question.correct ? 'Practice points: +850' : 'Practice points: +0'}</strong><p style={{ color: '#bfccdc', fontSize: 11, margin: '8px 0 0' }}>{question.explanation}</p></div>}</Card><div style={{ display: 'grid', gap: 14 }}><Card title="Round status" subtitle="Local browser timer only"><div style={{ font: '700 29px DM Mono', color: seconds < 5 ? '#fb897e' : '#f6ca57' }}>00:{String(seconds).padStart(2, '0')}</div><p className="card-sub" style={{ lineHeight: 1.7, marginTop: 9 }}>{revealed ? 'This round is complete.' : answer !== null ? 'Locked in. The answer stays hidden until the reveal.' : 'Choose once. You can’t change your answer after submission.'}</p>{!revealed && <Button onClick={() => setRevealed(true)} variant="outline" className="btn-small" testId="button-demo-end-round">Demo: end round</Button>}</Card><Card title="Your practice score" subtitle="Illustrative only"><strong style={{ font: '700 27px Space Grotesk', color: '#fff' }}>7,680</strong><p className="card-sub" style={{ marginTop: 5 }}>Not a server-verified score</p></Card><Card title="Keep it fair" subtitle="In multiplayer, the server is the referee."><p className="card-sub" style={{ lineHeight: 1.7 }}>Official deadlines, accepted answers, and points must come from a trusted game service. This countdown is display-only.</p><Button onClick={() => setLocation('/leaderboard')} variant="secondary" className="btn-small" testId="button-game-leaderboard"><Trophy size={13} /> Leaderboard</Button></Card></div></div>{revealed && <div style={{ display: 'flex', justifyContent: 'space-between', gap: 10, marginTop: 17, flexWrap: 'wrap' }}><Button onClick={() => setLocation('/leaderboard')} variant="outline" testId="button-game-see-leaderboard">See leaderboard</Button><Button onClick={onNext} testId="button-next-question">{number >= total ? 'View final results' : 'Next question'} <ArrowRight size={14} /></Button></div>}</main>;
}
function LeaderboardPage({ notify }: { notify: (s: string) => void }) {
  return <main className="page"><PageHeading eyebrow="The campus circuit" title="Leaderboard" subtitle="Sample rankings for your practice group. Local demo scores are not official." action={<Button onClick={() => { navigator.clipboard?.writeText('AptiQuiz leaderboard · local demo').catch(() => undefined); notify('Leaderboard summary copied'); }} variant="outline" testId="button-share-leaderboard"><Share2 size={14} /> Share board</Button>} /><div className="grid grid-4"><Stat label="Your rank" value="#4" icon={Award} delta="↑ 3 spots" /><Stat label="Practice score" value="7,680" icon={Zap} /><Stat label="Accuracy" value="82%" icon={Target} /><Stat label="Rounds played" value="10" icon={Gamepad2} /></div><Card title="Today’s room" subtitle="Placement warm-up · results shown for demonstration" style={{ marginTop: 18 } as never}><div className="table-wrap"><table className="table"><thead><tr><th>Rank</th><th>Player</th><th>Correct</th><th>Accuracy</th><th>Practice score</th><th>Move</th></tr></thead><tbody>{PLAYER_ROWS.map((row, i) => <tr key={row.name} style={row.name.includes('You') ? { background: '#f2f7ff' } : undefined} data-testid={`row-leaderboard-player-${i}`}><td><strong style={{ color: i < 3 ? '#bd8b1c' : '#62718a' }}>{String(i + 1).padStart(2, '0')}</strong></td><td><strong>{row.name}</strong><div className="card-sub">{row.college}</div></td><td>{row.correct}</td><td>{row.accuracy}</td><td><strong>{row.score}</strong></td><td style={{ color: row.move > 0 ? '#318253' : '#aa5a57' }}>{row.move > 0 ? <ArrowUp size={14} /> : <ArrowDown size={14} />} {Math.abs(row.move)}</td></tr>)}</tbody></table></div><div className="notice" style={{ marginTop: 12, background: '#f4f7fc', borderColor: '#e4ebf4', color: '#64748d' }} data-testid="text-leaderboard-disclaimer"><CircleHelp size={14} style={{ verticalAlign: 'middle', marginRight: 6 }} /> Rankings are seeded demo data. A live ranking needs an authoritative server feed.</div></Card></main>;
}
function ResultsPage({ notify, exportRows }: { notify: (s: string) => void; exportRows: () => void }) {
  return <main className="page"><PageHeading eyebrow="Session complete · local demo" title="You showed up. That counts." subtitle="A friendly snapshot of this sample round — not an official result." action={<Button onClick={() => { navigator.clipboard?.writeText('Aarav Mehta · 7,680 practice points · AptiQuiz demo').catch(() => undefined); notify('Demo result copied'); }} variant="outline" testId="button-share-result"><Share2 size={14} /> Share result</Button>} /><div style={{ background: '#152644', borderRadius: 17, padding: 25, color: 'white', display: 'flex', alignItems: 'center', gap: 18, flexWrap: 'wrap', marginBottom: 17 }}><div style={{ width: 58, height: 58, display: 'grid', placeItems: 'center', background: '#f4c54a', color: '#243149', borderRadius: 18 }}><Crown size={27} /></div><div style={{ flex: 1 }}><div className="eyebrow" style={{ color: '#f4c54a' }}>Your finish</div><h2 style={{ font: '700 25px Space Grotesk', margin: '0 0 3px' }}>Aarav Mehta</h2><p style={{ color: '#adbbd0', fontSize: 11, margin: 0 }}>Rank #4 in this demo room</p></div><div><div style={{ font: '700 30px DM Mono', color: '#fff' }}>7,680</div><div style={{ color: '#adbbd0', fontSize: 10 }}>practice points</div></div></div><div className="grid grid-4"><Stat label="Accuracy" value="82%" icon={Target} /><Stat label="Avg. response" value="6.4s" icon={Clock3} /><Stat label="Correct" value="8" icon={CheckCircle2} /><Stat label="Questions" value="10" icon={ListChecks} /></div><div className="grid grid-2" style={{ marginTop: 17 }}><Card title="The podium" subtitle="Top scores from this seeded demo"><div style={{ display: 'grid', gap: 8 }}>{PLAYER_ROWS.slice(0, 3).map((p, i) => <div key={p.name} style={{ display: 'flex', alignItems: 'center', gap: 11, background: i === 0 ? '#fff8e4' : '#f4f7fb', padding: 12, borderRadius: 10 }}><span style={{ font: '700 15px DM Mono', color: i === 0 ? '#b78b24' : '#71819a' }}>0{i + 1}</span><strong style={{ flex: 1, color: '#253854', fontSize: 12 }}>{p.name}</strong><strong style={{ color: '#263b5c', font: '700 13px DM Mono' }}>{p.score}</strong></div>)}</div></Card><Card title="Good next moves" subtitle="Turn this round into a better next one"><div style={{ display: 'grid', gap: 10 }}><Button href="/analytics" variant="outline" testId="button-results-analytics"><BarChart3 size={14} /> View detailed analysis</Button><Button onClick={exportRows} variant="outline" testId="button-export-results"><ArrowDown size={14} /> Export sample results</Button><Button href="/game" testId="button-play-again"><Gamepad2 size={14} /> Play again</Button><Button href="/host" variant="secondary" testId="button-results-dashboard">Back to dashboard</Button></div></Card></div></main>;
}
function PlayerAnalytics() {
  const topics = [['Quantitative', 85, '#2779e7'], ['Logical reasoning', 72, '#43a584'], ['Verbal ability', 91, '#d6a52f'], ['Data interpretation', 68, '#8b70d2']];
  return <main className="page"><PageHeading eyebrow="Your practice profile" title="Get sharper, one topic at a time." subtitle="A local demo snapshot of your accuracy and pace across recent sessions." /><div className="grid grid-4"><Stat label="Overall accuracy" value="82.4%" icon={Target} delta="+4.2%" /><Stat label="Average speed" value="6.4 sec" icon={Clock3} /><Stat label="Correct answers" value="164" icon={CheckCircle2} /><Stat label="Total practice XP" value="18,240" icon={Zap} /></div><div className="grid grid-2" style={{ marginTop: 17 }}><Card title="Topic performance" subtitle="Accuracy · recent practice sessions"><div style={{ display: 'grid', gap: 20 }}>{topics.map(([name, score, color]) => <div key={name as string} data-testid={`metric-topic-${String(name).toLowerCase().replaceAll(' ', '-')}`}><div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8, fontSize: 11 }}><strong style={{ color: '#394b66' }}>{name}</strong><span style={{ fontFamily: 'DM Mono', color: '#66758c' }}>{score}%</span></div><div className="progress"><span style={{ width: `${score}%`, background: color as string }} /></div></div>)}</div></Card><Card title="Your current streak" subtitle="Small reps compound"><div style={{ display: 'flex', alignItems: 'center', gap: 13, background: '#fff7e2', padding: 16, borderRadius: 12 }}><Flame size={27} color="#d59c1a" /><div><strong style={{ font: '700 22px Space Grotesk', color: '#493c1c' }}>7 days</strong><div className="card-sub">You’ve practiced every day this week.</div></div></div><div className="grid grid-2" style={{ marginTop: 15 }}>{[['Current level', 'Level 08'], ['XP to next level', '760 XP'], ['Best topic', 'Verbal · 91%'], ['Focus next', 'Data interp.']].map(([a, b]) => <div key={a} style={{ padding: 12, background: '#f4f7fb', borderRadius: 9 }}><div className="card-sub">{a}</div><strong style={{ color: '#2d405d', fontSize: 12 }}>{b}</strong></div>)}</div></Card></div><Card title="Recent badges" subtitle="Earned in this local demo profile" ><div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>{[['Accuracy builder', Target], ['Quick thinker', Zap], ['Logic streak', Brain], ['Seven-day habit', Flame]].map(([label, Icon]) => <span key={label as string} className="badge badge-gold" style={{ padding: '9px 12px' }}><Icon size={13} /> {label as string}</span>)}</div></Card></main>;
}
function LeaguePage({ period, setPeriod }: { period: string; setPeriod: (p: string) => void }) {
  const rows = [
    ['Northbridge Institute', '842', '8,624', '128,450'],
    ['Eastlake University', '716', '8,210', '116,890'],
    ['Meridian College', '604', '7,980', '104,370'],
    ['Western Tech', '589', '7,842', '98,640'],
    ['South City Engineering', '477', '7,620', '87,210'],
  ];
  return <main className="page"><PageHeading eyebrow="Campus vs campus" title="College Aptitude League" subtitle="A seeded sample table, built for campus rivalry. Rankings update when a connected league service is added." /><Card title="The standings" subtitle={`${period} view · sample values for product preview`}><div role="tablist" aria-label="League time period" style={{ display: 'flex', gap: 6, marginBottom: 18, flexWrap: 'wrap' }}>{['Today', 'Week', 'Month', 'Season'].map((p) => <button type="button" role="tab" aria-selected={period === p} key={p} className={`btn btn-small ${period === p ? 'btn-primary' : 'btn-outline'}`} onClick={() => setPeriod(p)} data-testid={`tab-league-${p.toLowerCase()}`}>{p}</button>)}</div><div className="table-wrap"><table className="table"><thead><tr><th>Rank</th><th>College</th><th>Players</th><th>Avg. score</th><th>League points</th></tr></thead><tbody>{rows.map((row, i) => <tr key={row[0]} data-testid={`row-college-${i}`}><td><strong style={{ color: i === 0 ? '#b68410' : '#596982' }}>{String(i + 1).padStart(2, '0')}</strong></td><td><strong>{row[0]}</strong>{i === 0 && <span className="badge badge-gold" style={{ marginLeft: 8 }}>Your college</span>}</td><td>{row[1]}</td><td>{row[2]}</td><td><strong>{row[3]}</strong></td></tr>)}</tbody></table></div></Card><div className="grid grid-2" style={{ marginTop: 17 }}><Card title="Top players" subtitle="Standout practice scores this week">{PLAYER_ROWS.slice(0, 4).map((p, i) => <div key={p.name} style={{ display: 'flex', alignItems: 'center', gap: 11, padding: '11px 0', borderBottom: i < 3 ? '1px solid #edf1f6' : 0 }}><span style={{ color: '#bc8e28', font: '500 11px DM Mono' }}>0{i + 1}</span><div style={{ flex: 1 }}><strong style={{ color: '#344761', fontSize: 12 }}>{p.name}</strong><div className="card-sub">{p.college}</div></div><strong style={{ font: '600 12px DM Mono', color: '#364b68' }}>{p.score}</strong></div>)}</Card><Card title="Season pulse" subtitle="This period’s demo activity"><div style={{ font: '700 34px Space Grotesk', color: '#1b6fd8' }}>2,418</div><p className="card-sub">students played across 38 colleges</p><div className="progress" style={{ marginTop: 18 }}><span style={{ width: period === 'Today' ? '24%' : period === 'Week' ? '68%' : period === 'Month' ? '81%' : '92%' }} /></div><p className="card-sub" style={{ marginTop: 8 }}>League energy · {period.toLowerCase()} snapshot</p></Card></div></main>;
}
function DailyPage({ notify }: { notify: (s: string) => void }) {
  const [started, setStarted] = useState(false);
  const [done, setDone] = useState(() => initial('dailyDone', false));
  return <main className="page"><PageHeading eyebrow="One set. Every day." title="Daily challenge" subtitle="Ten focused questions to build a placement-prep habit that sticks." action={<span className="badge badge-gold"><Flame size={13} /> 7 day streak</span>} /><div className="grid grid-2" style={{ alignItems: 'stretch' }}><div className="card" style={{ background: '#152644', color: '#fff', display: 'flex', flexDirection: 'column', justifyContent: 'space-between', minHeight: 295 }}><div><div className="eyebrow" style={{ color: '#f1c34d' }}>Today’s set · 14 June</div><h2 style={{ font: '700 30px Space Grotesk', maxWidth: 350, margin: '12px 0' }}>Keep your edge<br />in motion.</h2><p style={{ color: '#acbbd0', fontSize: 12, lineHeight: 1.7 }}>Quant, logic, and verbal questions mixed into one compact daily workout.</p><div style={{ display: 'flex', gap: 8, margin: '20px 0' }}><span className="badge" style={{ background: '#253959', color: '#d8e5f7' }}>10 questions</span><span className="badge" style={{ background: '#253959', color: '#d8e5f7' }}>5 minutes</span></div></div><Button onClick={() => { if (done) { setDone(false); persist('dailyDone', false); } setStarted(true); notify('Daily challenge started · local practice'); }} variant="gold" testId="button-start-daily">{done ? 'Try again' : started ? 'Continue challenge' : 'Start challenge'} <ArrowRight size={14} /></Button></div><div className="grid grid-2"><Stat label="Today’s score" value={done ? '8,420' : '—'} icon={Target} /><Stat label="Personal best" value="9,180" icon={Star} /><Stat label="Current streak" value="7 days" icon={Flame} /><Stat label="Global rank" value="#2,418" icon={Trophy} /></div></div>{started && <Card title="Challenge practice" subtitle="Local demo progression; points are illustrative." className="" ><p className="page-sub">Question 1 of 10 · A team completes 3/5 of a task in 6 days. At the same pace, how long for the whole task?</p><div className="grid grid-2" style={{ marginTop: 13 }}>{['8 days', '10 days', '12 days', '15 days'].map((x, i) => <Button key={x} onClick={() => { if (i === 2) { setDone(true); persist('dailyDone', true); setStarted(false); notify('Challenge complete · score saved on this device'); } else notify('Answer saved locally · keep going'); }} variant="outline" testId={`button-daily-answer-${i}`}>{x}</Button>)}</div></Card>}</main>;
}
function TeamPage({ notify }: { notify: (s: string) => void }) {
  const [joined, setJoined] = useState(false);
  const membersA = ['Aarav Mehta', 'Priya Nair', 'Kabir Shah']; const membersB = ['Rahul Sharma', 'Ishita Rao', 'Neha Kapoor'];
  const team = (name: string, members: string[], score: string, blue: boolean) => <div className="card" style={{ background: blue ? '#edf5ff' : '#fff7e6', borderColor: blue ? '#d9e8fb' : '#f3e6c6' }}><div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}><div><span className={`badge ${blue ? 'badge-blue' : 'badge-gold'}`}>{name}</span><h2 style={{ font: '700 31px Space Grotesk', color: '#263958', margin: '14px 0 2px' }}>{score}</h2><div className="card-sub">combined practice points</div></div><Users size={23} color={blue ? '#347cdb' : '#bd8e25'} /></div><div style={{ display: 'grid', gap: 9, marginTop: 18 }}>{members.map((m, i) => <div key={m} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderTop: `1px solid ${blue ? '#dbe8f6' : '#efe5ce'}`, paddingTop: 9 }}><span style={{ fontSize: 11, color: '#41526d' }}>{m}{m === 'Aarav Mehta' && <span className="badge badge-blue" style={{ marginLeft: 6 }}>You</span>}</span><span style={{ font: '500 11px DM Mono', color: '#63718a' }}>{[2960, 2680, 2230][i]} XP</span></div>)}</div><div className="progress" style={{ marginTop: 18 }}><span style={{ width: blue ? '74%' : '68%', background: blue ? '#347fe0' : '#d8a52d' }} /></div><p className="card-sub" style={{ marginTop: 7 }}>Team momentum · {members.length} of 3 players</p></div>;
  return <main className="page"><PageHeading eyebrow="Squad up" title="Team battle" subtitle="Bring your study group together. This sample matchup is not a live multiplayer room." action={<Button onClick={() => { setJoined(!joined); notify(joined ? 'You left the demo battle' : 'You joined Team Blue'); }} variant={joined ? 'secondary' : 'primary'} testId="button-join-team">{joined ? 'Leave battle' : 'Join Team Blue'}</Button>} /><div className="grid grid-2" style={{ alignItems: 'center' }}>{team('Team Blue', membersA, '7,870', true)}<div style={{ textAlign: 'center', color: '#8b98ac', font: '700 14px DM Mono' }}>VS<div style={{ width: 36, height: 36, margin: '10px auto', borderRadius: '50%', display: 'grid', placeItems: 'center', background: '#eef2f8', color: '#3c5271' }}>VS</div></div>{team('Team Gold', membersB, '7,420', false)}</div><div className="notice" style={{ marginTop: 17, background: '#f1f6fd', borderColor: '#dce8f6', color: '#4d6687' }}><Radio size={14} style={{ verticalAlign: 'middle', marginRight: 6 }} /> Local score and roster preview. Team play will connect to a room service in a future version.</div></main>;
}
function HostAnalytics({ exportRows }: { exportRows: () => void }) {
  const vals = [76, 88, 61, 92, 69, 82, 71, 95, 66, 84];
  return <main className="page"><PageHeading eyebrow="Host studio / insights" title="A better read on every round." subtitle="Sample session analytics for hosts. Use these patterns to tune your next set." action={<Button onClick={exportRows} variant="outline" testId="button-host-export"><ArrowDown size={14} /> Export results</Button>} /><div className="grid grid-4"><Stat label="Participants" value="186" icon={Users} /><Stat label="Average score" value="7,420" icon={Zap} /><Stat label="Average accuracy" value="76.8%" icon={Target} /><Stat label="Avg. response" value="8.2s" icon={Clock3} /></div><div className="grid grid-2" style={{ marginTop: 17 }}><Card title="Question-wise accuracy" subtitle="Correct response rate · seeded session sample"><div style={{ height: 170, display: 'flex', alignItems: 'end', justifyContent: 'space-around', gap: 8, borderBottom: '1px solid #e5ebf3', padding: '0 6px' }}>{vals.map((v, i) => <div key={i} data-testid={`chart-question-${i}`} style={{ display: 'grid', justifyItems: 'center', gap: 7, height: '100%', alignContent: 'end', flex: 1 }}><span style={{ font: '10px DM Mono', color: '#6e7e96' }}>{v}%</span><div style={{ height: `${v}%`, width: '70%', maxWidth: 27, background: i === 2 ? '#e2ae35' : '#4388e7', borderRadius: '5px 5px 0 0' }} /><span className="card-sub">Q{i + 1}</span></div>)}</div></Card><Card title="Topic performance" subtitle="Accuracy by topic"><div style={{ display: 'grid', gap: 17 }}>{[['Quantitative', 74], ['Logical reasoning', 82], ['Verbal ability', 88], ['Data interpretation', 63]].map(([topic, score]) => <div key={topic as string}><div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11, marginBottom: 7 }}><strong style={{ color: '#41516a' }}>{topic}</strong><span className="card-sub">{score}%</span></div><div className="progress"><span style={{ width: `${score}%` }} /></div></div>)}</div></Card></div><div className="grid grid-3" style={{ marginTop: 17 }}><Card title="Most difficult" subtitle="Question 08 · ratios"><span className="badge badge-red">42% correct</span><p style={{ color: '#43536d', fontSize: 11, lineHeight: 1.6, marginTop: 10 }}>A mixture ratio question took the longest and had the lowest correct rate.</p></Card><Card title="Easiest question" subtitle="Question 02 · number series"><span className="badge badge-green">94% correct</span><p style={{ color: '#43536d', fontSize: 11, lineHeight: 1.6, marginTop: 10 }}>A clear sequence prompt landed well with almost every participant.</p></Card><Card title="Common miss" subtitle="Question 08 · option C"><span className="badge badge-gold">Option C · 37%</span><p style={{ color: '#43536d', fontSize: 11, lineHeight: 1.6, marginTop: 10 }}>A useful signal to revisit the ratio setup before the next session.</p></Card></div></main>;
}

function App() {
  return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><RoutedErrorBoundary><Router /></RoutedErrorBoundary></WouterRouter><Toaster /></TooltipProvider></QueryClientProvider>;
}
function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}
export default App;
